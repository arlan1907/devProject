package main;

public class Product {

    private String productName;
    private String category;
    private double price;
    private int stockQuantity;

    /*
    Create:
    1. Constructor
    2. Getters and Setters
    3. toString(); method
     */
}
