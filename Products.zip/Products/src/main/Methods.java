package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
/*
@author Arslan Kabulniyazov
 */
public class Methods {

    public static void main(String[] args) {
        System.out.println(PRODUCTS);
    }

    public static List<Product> getProducts() {
        return PRODUCTS;
    }

    private static final List<Product> PRODUCTS;

    static {
        PRODUCTS = new ArrayList<>();
        // TODO - Read the csv file and store all data to list of products
    }

    /**
     * Create a method that takes list of products, a Predicate<Product>,
     * and a Consumer<Product> as parameters.
     * This method will filter the products based on the Predicate
     * and then apply the Consumer to each filtered product.
     *
     * Example:
     *         Predicate<Product> expensiveProducts = p -> p.getPrice() > 500.0;
     *         Consumer<Product> printProductDetails = p -> System.out.println(p.getProductName() + ": $" + p.getPrice() + ", Stock: " + p.getStockQuantity());
     *
     *         .processProducts(PRODUCTS, expensiveProducts, printProductDetails);
     *
     *         Output:
     *             "Monitor: $699.94, Stock: 245\n" +
     *                 "T-Shirt: $974.46, Stock: 160\n" +
     *                 "Desk: $588.47, Stock: 239\n" +
     *                 "Desk: $1489.94, Stock: 208\n" +
     *                 "Doll: $681.97, Stock: 126\n" +
     *                 "Jacket: $1338.63, Stock: 196\n" +
     *                 "Laptop: $1216.56, Stock: 37\n" +
     *                 "Board Game: $1388.17, Stock: 200\n" +
     *                 "Action Figure: $1343.51, Stock: 72\n" +
     *                 "Doll: $1395.92, Stock: 244\n" +
     *                 "Tablet: $1010.29, Stock: 278\n" +
     *                 "Keyboard: $1205.64, Stock: 170\n" +
     *                 "Magazine: $537.9, Stock: 197\n" +
     *                 "Textbook: $1199.81, Stock: 261\n" +
     *                 "Novel: $973.48, Stock: 228\n" +
     *                 "Desk: $1139.07, Stock: 191\n" +
     *                 "Keyboard: $1318.66, Stock: 248\n" +
     *                 "Keyboard: $771.58, Stock: 63\n" +
     *                 "Action Figure: $706.13, Stock: 14\n" +
     *                 "Puzzle: $1060.5, Stock: 231\n" +
     *                 "Mouse: $1095.81, Stock: 123\n" +
     *                 "Novel: $925.03, Stock: 118\n" +
     *                 "Jacket: $1153.81, Stock: 36\n" +
     *                 "Lamp: $945.27, Stock: 212\n" +
     *                 "Board Game: $1472.72, Stock: 174\n" +
     *                 "Tablet: $766.37, Stock: 97\n" +
     *                 "Smartphone: $933.88, Stock: 135\n" +
     *                 "Textbook: $1310.31, Stock: 168\n" +
     *                 "Mouse: $686.93, Stock: 283\n" +
     *                 "Magazine: $575.46, Stock: 17\n" +
     *                 "Magazine: $838.03, Stock: 255\n" +
     *                 "Mouse: $1174.32, Stock: 166\n" +
     *                 "Chair: $1000.92, Stock: 18\n" +
     *                 "Doll: $1343.0, Stock: 43\n" +
     *                 "Laptop: $987.13, Stock: 269";
     *
     * @param products
     * @param condition
     * @param action
     */
    public static void processProducts(List<Product> products, Predicate<Product> condition, Consumer<Product> action) {
        // TODO
    }

    /**
     * This method loops through the list of products, and applies the condition function to filter employees.
     * Then apply the attribute function to transform the product data.
     * Calculate the average price of the filtered product and add it to the result list.
     *
     * Example:
     *         Condition<Product> electronicsCategoryCondition = p -> "Electronics".equals(p.getCategory());
     *         AttributeFunction<Product, String> productNameToUpperCase = p -> p.getProductName().toUpperCase();
     *
     *         List<String> result = ProductProcessor.processProducts(products, electronicsCategoryCondition, productNameToUpperCase);
     *
     *         Output:
     *         result:
     *         MONITOR
     *         LAPTOP
     *         MONITOR
     *         LAPTOP
     *         KEYBOARD
     *         KEYBOARD
     *         MOUSE
     *         SMARTPHONE
     *         MOUSE
     *         MOUSE
     *         KEYBOARD
     *         LAPTOP
     *         Average Price: 812.18
     *
     * @param products
     * @param condition
     * @param function
     * @return
     */
    public static List<String> processProducts(List<Product> products, Predicate<Product> condition, Function<Product, String> function) {
        //TODO
        return null;
    }

    /**
     * This method takes a list of Product objects. Then takes a second parameter of type String which will be used by the BiPredicate.
     * Filters products based on a BiPredicate<Product, String> condition.
     * Transforms each filtered product using a Function<Product, String>.
     * Calculates the total price and average price of the filtered products.
     * Adds the average price to the result list if there are any filtered products.
     * @param products
     * @param secondParameter
     * @param condition
     * @param function
     * @return
     *
     * Example:
     *         double priceThreshold = 500.0;
     *         BiPredicate<Product, Double> expensiveProducts = (p, threshold) -> p.getPrice() > threshold;
     *         Function<Product, String> productInfo = p -> p.getName() + ": $" + p.getPrice();
     *
     *         List<String> result = processProducts(products, priceThreshold, expensiveProducts, productInfo);
     *
     *         Output:
     *          result:
     *          Monitor: $699.94
     *          T-Shirt: $974.46
     *          Desk: $588.47
     *          ...
     *          Average Price: 1035.7034285714287
     */
    public static List<String> processProducts(
            List<Product> products,
            double secondParameter,
            BiPredicate<Product, Double> condition,
            Function<Product, String> function) {
            //TODO
        return null;
    }

}
